﻿[General]
name=Pogoro
font=Arial
size=16

[Punctuation]
versesegments=a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz

[Characters]
Chr01=a/A
Chr02=b/B
Chr03=bw Bw
Chr04=ch Ch
Chr05=d/D
Chr06=e/E
Chr07=f/F
Chr08=g/G
Chr09=gw Gw
Chr10=h/H
Chr11=hw Hw
Chr12=i/I
Chr13=j/J
Chr14=k/K
Chr15=kw Kw
Chr16=l/L
Chr17=ly Ly
Chr18=m/M
Chr19=mb Mb
Chr20=ml Ml
Chr21=mp Mp
Chr22=mt Mt
Chr23=mw Mw
Chr24=n/N
Chr25=nd Nd
Chr26=ng Ng
Chr27=nsy Nsy
Chr28=ng' Ng'
Chr29=o/O
Chr30=p/P
Chr31=r/R
Chr32=s/S
Chr33=sh Sh
Chr34=t/T
Chr35=tw Tw
Chr36=u/U
Chr37=v/V
Chr38=vy Vy
Chr39=w/W
Chr40=y/Y
Chr41=z/Z
Chr42=zy Zy
