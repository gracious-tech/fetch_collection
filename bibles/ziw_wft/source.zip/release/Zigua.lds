[General]
name=Zigua
size=12
font=Arial

[Punctuation]
crossreferences=Cross
versesegments=a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz

[Characters]
Chr01=a/A
Chr02=b/B
Chr03=ch Ch
Chr04=d/D
Chr05=dy Dy
Chr06=e/E
Chr07=f/F
Chr08=fy Fy
Chr09=g/G
Chr10=h/H
Chr11=i/I
Chr12=j/J
Chr13=k/K
Chr14=l/L
Chr15=m/M
Chr16=mb Mb
Chr17=mk Mk
Chr18=mp Mp
Chr19=n/N
Chr20=nd Nd
Chr21=ng Ng
Chr22=ng' Ng'
Chr23=nj Nj
Chr24=nk Nk
Chr25=nt Nt
Chr26=o/O
Chr27=p/P
Chr28=pw Pw
Chr29=r/R
Chr30=s/S
Chr31=t/T
Chr32=u/U
Chr33=v/V
Chr34=vy Vy
Chr35=w/W
Chr36=y/Y
Chr37=z/Z
Chr38='
