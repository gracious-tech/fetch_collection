[General]
size=16
font=Arial
fontFeatureSettings=
htmlLang=
name=Ngindo
UpperCaseLetters=
LowerCaseLetters=
NoCaseLetters=
RTL=F

[Punctuation]
versesegments=a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz
diacritics=
footnotes=
crossreferences=
wordbreakchars=
medial=

[Characters]
