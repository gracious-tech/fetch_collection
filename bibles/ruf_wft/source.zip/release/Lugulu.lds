﻿[General]
name=Lugulu
size=12
font=Verdana

[Punctuation]
versesegments=a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz

[Characters]
Chr01=a/A
Chr02=b/B
Chr03=bw Bw
Chr04=ch Ch
Chr05=d/D
Chr06=dh Dh
Chr07=e/E
Chr08=f/F
Chr09=g/G
Chr10=gh Gh
Chr11=ghw Ghw
Chr12=h/H
Chr13=i/I
Chr14=j/J
Chr15=k/K
Chr16=kw Kw
Chr17=l/L
Chr18=m/M
Chr19=mb Mb
Chr20=mn Mn
Chr21=mv Mv
Chr22=mw Mw
Chr23=n/N
Chr24=nd Nd
Chr25=ng Ng
Chr26=ng' Ng'
Chr27=nj Nj
Chr28=nw Nw
Chr29=ny Ny
Chr30=nz Nz
Chr31=o/O
Chr32=p/P
Chr33=pf Pf
Chr34=r/R
Chr35=s/S
Chr36=sh Sh
Chr37=t/T
Chr38=th Th
Chr39=ts Ts
Chr40=u/U
Chr41=v/V
Chr42=w/W
Chr43=y/Y
Chr44=z/Z
Chr45='
