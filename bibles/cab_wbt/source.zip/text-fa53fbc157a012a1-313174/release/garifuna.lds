﻿[General]
name=garifuna
font=Charis SIL
size=16
UpperCaseLetters=AÁBCDEÉFGHIÍJKLMNÑOÓPQRSTUÚÜVWXYZ
LowerCaseLetters=aábcdeéfghiíjklmnñoópqrstuúüvwxyz
NoCaseLetters=ꞌ

[Characters]
Chr01=a/A á/Á
Chr02=b/B
Chr03=c/C
Chr04=d/D
Chr05=e/E é/É
Chr06=f/F
Chr07=g/G
Chr08=h/H
Chr09=i/I í/Í
Chr10=j/J
Chr11=k/K
Chr12=l/L
Chr13=m/M
Chr14=n/N
Chr15=ñ/Ñ
Chr16=o/O ó/Ó
Chr17=p/P
Chr18=q/Q
Chr19=r/R
Chr20=s/S
Chr21=t/T
Chr22=u/U ú/Ú ü/Ü ǘ Ǘ
Chr23=v/V
Chr24=w/W
Chr25=x/X
Chr26=y/Y
Chr27=z/Z
Chr28=ꞌ

[Punctuation]
versesegments=a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz

