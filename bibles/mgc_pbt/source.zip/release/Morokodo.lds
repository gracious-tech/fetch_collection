[General]
codepage=65001
AutoKeyboardSwitching=F
DialogFontsize=14
LowerCaseLetters=aäbdeëfghiïjklmnŋoöɔprstuüvwyz
NoCaseLetters=
RTL=F
UpperCaseLetters=AÄBDEËFGHIÏJKLMNŊOÖƆPRSTUÜVWYZ
errors=
font=Doulos SIL
name=Morokodo
separator=/
size=14

[Checking]

[Characters]
Chr01=a/A
Chr02=ä/Ä
Chr03=b/B
Chr04='b 'B
Chr05=d/D
Chr06='d 'D
Chr07=e/E
Chr08='e 'E
Chr09=ë/Ë
Chr10=f/F
Chr11=g/G
Chr12=gb Gb
Chr13=h/H
Chr14=i/I
Chr15=ï/Ï
Chr16=j/J
Chr17='j 'J
Chr18=k/K
Chr19=l/L
Chr20=m/M
Chr21=n/N
Chr22=ŋ/Ŋ
Chr23=o/O
Chr24=ö/Ö
Chr25=ɔ/Ɔ
Chr26=p/P
Chr27=r/R
Chr28=s/S
Chr29=t/T
Chr30=u/U
Chr31=ü/Ü
Chr32=v/V
Chr33=w/W
Chr34=y/Y
Chr35=z/Z

[Punctuation]
diacritics=
diacriticsfollow=No
footnotes=
medial='
versesegments=a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz
