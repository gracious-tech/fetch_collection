[General]
codepage=65001
AutoKeyboardSwitching=F
DialogFontsize=14
LowerCaseLetters=
NoCaseLetters=
RTL=F
UpperCaseLetters=
errors=
font=Arial Black
name=Kutu
separator=/
size=14

[Checking]

[Characters]
Chr01='

[Punctuation]
diacritics=
diacriticsfollow=No
footnotes=
medial=
versesegments=a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz
