﻿[General]
size=14
font=Arial
name=Nguu

[Punctuation]
versesegments=a b c d e f g h i j k l m n o p q r s t u v w x y z aa bb cc dd ee ff gg hh ii jj kk ll mm nn oo pp qq rr ss tt uu vv ww xx yy zz

[Characters]
Chr01=a/A
Chr02=b/B
Chr03=ch Ch
Chr04=d/D
Chr05=dy Dy
Chr06=e/E
Chr07=f/F
Chr08=fy Fy
Chr09=g/G
Chr10=gw Gw
Chr11=h/H
Chr12=i/I
Chr13=j/J
Chr14=k/K
Chr15=kw Kw
Chr16=l/L
Chr17=lw Lw
Chr18=m/M
Chr19=mb Mb
Chr20=mk Mk
Chr21=mp'h Mp'h
Chr22=mv Mv
Chr23=mw Mw
Chr24=my My
Chr25=n/N
Chr26=nd Nd
Chr27=ng Ng
Chr28=ng' Ng'
Chr29=nk'h Nk'h
Chr30=ny Ny
Chr31=nt Nt
Chr32=nt'h Nt'h
Chr33=nz Nz
Chr34=o/O
Chr35=p/P
Chr36=s/S
Chr37=sh Sh
Chr38=t/T
Chr39=u/U
Chr40=v/V
Chr41=w/W
Chr42=y/Y
Chr43=yw Yw
Chr44=z/Z
Chr45=zw Zw
Chr46='
